package com.wanda.athena.example.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wanda.athena.example.service.ExampleService;

@Controller
public class ExampleServiceController {
	@Autowired
	private ExampleService exampleService;

	@RequestMapping(value = "/test", method = RequestMethod.GET)
	@ResponseBody
	public String serverStatus() {
		return exampleService.helloworld();
	}
	
	public void setExampleService(ExampleService exampleService) {
		this.exampleService = exampleService;
	}

}
