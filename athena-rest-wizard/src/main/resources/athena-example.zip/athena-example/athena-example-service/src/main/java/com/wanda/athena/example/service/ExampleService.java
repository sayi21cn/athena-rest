package com.wanda.athena.example.service;

public interface ExampleService {
	public String helloworld();
}
